"""
Structured logging: console (INFO+) + rotating file (DEBUG+).
"""
import logging
import logging.handlers
from pathlib import Path

# Always write logs next to wherever this package lives
_LOG_DIR  = Path(__file__).resolve().parent.parent / "logs"
_LOG_FILE = _LOG_DIR / "trading_bot.log"
_READY    = False


def setup_logging() -> logging.Logger:
    global _READY
    if _READY:
        return logging.getLogger("trading_bot")

    _LOG_DIR.mkdir(parents=True, exist_ok=True)

    fmt = logging.Formatter(
        "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%Y-%m-%dT%H:%M:%S",
    )
    root = logging.getLogger("trading_bot")
    root.setLevel(logging.DEBUG)

    ch = logging.StreamHandler()
    ch.setLevel(logging.INFO)
    ch.setFormatter(fmt)

    fh = logging.handlers.RotatingFileHandler(
        _LOG_FILE, maxBytes=5 * 1024 * 1024, backupCount=3, encoding="utf-8"
    )
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(fmt)

    root.addHandler(ch)
    root.addHandler(fh)
    _READY = True
    root.debug("Logging initialised → %s", _LOG_FILE)
    return root


def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(f"trading_bot.{name}")
