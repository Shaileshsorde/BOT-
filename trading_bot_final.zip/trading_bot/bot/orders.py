"""
High-level order placement — sits between the CLI and the raw client.

Handles:
  - calling validators before touching the API
  - defaulting time_in_force for LIMIT orders
  - wrapping the raw response in an OrderResult model
  - logging the full lifecycle of every order
"""
from __future__ import annotations

import json
from typing import Optional

from .client    import BinanceFuturesClient, BinanceAPIError
from .validators import validate_all
from .logging_config import get_logger

log = get_logger("orders")

_DEFAULT_TIF = "GTC"


class OrderResult:
    """Normalised, human-friendly view of a Binance order response."""

    def __init__(self, raw: dict) -> None:
        self.raw           = raw
        self.order_id      = raw.get("orderId",      -1)
        self.symbol        = raw.get("symbol",        "")
        self.status        = raw.get("status",        "")
        self.side          = raw.get("side",          "")
        self.order_type    = raw.get("type",          "")
        self.orig_qty      = raw.get("origQty",       "0")
        self.executed_qty  = raw.get("executedQty",   "0")
        self.avg_price     = raw.get("avgPrice",      "0")
        self.price         = raw.get("price",         "0")
        self.stop_price    = raw.get("stopPrice",     "0")
        self.time_in_force = raw.get("timeInForce",   "")

    def summary_lines(self) -> list[str]:
        lines = [
            f"  Order ID       : {self.order_id}",
            f"  Symbol         : {self.symbol}",
            f"  Side           : {self.side}",
            f"  Type           : {self.order_type}",
            f"  Status         : {self.status}",
            f"  Orig Qty       : {self.orig_qty}",
            f"  Executed Qty   : {self.executed_qty}",
        ]
        if self.order_type == "LIMIT":
            lines += [
                f"  Limit Price    : {self.price}",
                f"  Time-In-Force  : {self.time_in_force}",
            ]
        if self.order_type == "STOP_MARKET":
            lines.append(f"  Stop Price     : {self.stop_price}")
        if float(self.avg_price) > 0:
            lines.append(f"  Avg Fill Price : {self.avg_price}")
        return lines


def place_order(
    client:        BinanceFuturesClient,
    symbol:        str,
    side:          str,
    order_type:    str,
    quantity,
    price          = None,
    stop_price     = None,
    time_in_force  = None,
    reduce_only:   bool = False,
) -> OrderResult:
    """
    Validate → place → return OrderResult.

    Raises
    ------
    ValueError        bad user input (caught before the API is called)
    BinanceAPIError   API rejection
    ConnectionError   network unreachable
    TimeoutError      request timed out
    """
    params = validate_all(symbol, side, order_type, quantity, price, stop_price)

    tif = None
    if params["order_type"] == "LIMIT":
        tif = (time_in_force or _DEFAULT_TIF).upper()

    log.info(
        "Order request | symbol=%s side=%s type=%s qty=%s price=%s stop=%s tif=%s",
        params["symbol"], params["side"], params["order_type"],
        params["quantity"], params["price"], params["stop_price"], tif,
    )

    raw = client.place_order(
        symbol        = params["symbol"],
        side          = params["side"],
        order_type    = params["order_type"],
        quantity      = params["quantity"],
        price         = params["price"],
        stop_price    = params["stop_price"],
        time_in_force = tif,
        reduce_only   = reduce_only,
    )

    result = OrderResult(raw)
    log.info(
        "Order placed | orderId=%s status=%s executedQty=%s avgPrice=%s",
        result.order_id, result.status, result.executed_qty, result.avg_price,
    )
    log.debug("Raw response:\n%s", json.dumps(raw, indent=2))
    return result
