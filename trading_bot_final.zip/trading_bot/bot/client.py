"""
Low-level Binance USDT-M Futures Testnet REST client.

Responsibilities
----------------
- HMAC-SHA256 request signing
- HTTP execution (GET / POST / DELETE)
- Structured DEBUG logging of every request & response
- Raising BinanceAPIError on API-level or HTTP-level failures
"""
from __future__ import annotations

import hashlib
import hmac
import os
import time
from typing import Any, Optional
from urllib.parse import urlencode

import requests

from .logging_config import get_logger

log = get_logger("client")

TESTNET_BASE_URL = "https://testnet.binancefuture.com"
DEFAULT_RECV_WINDOW = 5_000   # ms


class BinanceAPIError(Exception):
    """Raised when Binance returns an error payload or a non-2xx status."""

    def __init__(self, code: int, message: str, http_status: int = 0) -> None:
        self.code        = code
        self.message     = message
        self.http_status = http_status
        super().__init__(f"[HTTP {http_status}] Binance error {code}: {message}")


class BinanceFuturesClient:
    """
    Thin, dependency-free wrapper around the Binance Futures REST API.

    Parameters
    ----------
    api_key     : Binance API key  (falls back to env var BINANCE_API_KEY)
    api_secret  : Binance secret   (falls back to env var BINANCE_API_SECRET)
    base_url    : Override to point at mainnet or a different testnet
    recv_window : Request validity window in ms (default 5000)
    timeout     : HTTP timeout in seconds
    """

    def __init__(
        self,
        api_key:     Optional[str] = None,
        api_secret:  Optional[str] = None,
        base_url:    str           = TESTNET_BASE_URL,
        recv_window: int           = DEFAULT_RECV_WINDOW,
        timeout:     int           = 10,
    ) -> None:
        self.api_key     = api_key    or os.environ.get("BINANCE_API_KEY",    "")
        self.api_secret  = api_secret or os.environ.get("BINANCE_API_SECRET", "")
        self.base_url    = base_url.rstrip("/")
        self.recv_window = recv_window
        self.timeout     = timeout

        if not self.api_key or not self.api_secret:
            raise ValueError(
                "API credentials are missing.\n"
                "  Option A: set env vars  BINANCE_API_KEY  and  BINANCE_API_SECRET\n"
                "  Option B: pass  --api-key  and  --api-secret  on the command line"
            )

        self._session = requests.Session()
        self._session.headers.update({"X-MBX-APIKEY": self.api_key})
        log.info("Client ready → %s", self.base_url)

    # ── signing helpers ────────────────────────────────────────────────────

    @staticmethod
    def _now_ms() -> int:
        return int(time.time() * 1_000)

    def _sign(self, params: dict) -> str:
        qs = urlencode(params)
        return hmac.new(
            self.api_secret.encode(),
            qs.encode(),
            hashlib.sha256,
        ).hexdigest()

    def _signed(self, params: dict) -> dict:
        p = {k: v for k, v in params.items() if v is not None}
        p["timestamp"]  = self._now_ms()
        p["recvWindow"] = self.recv_window
        p["signature"]  = self._sign(p)
        return p

    # ── core HTTP ──────────────────────────────────────────────────────────

    def _request(
        self,
        method:  str,
        path:    str,
        params:  Optional[dict] = None,
        signed:  bool           = True,
    ) -> Any:
        url = f"{self.base_url}{path}"
        if signed:
            params = self._signed(params or {})

        # log without leaking the signature
        safe = {k: v for k, v in (params or {}).items() if k != "signature"}
        log.debug("→ %s %s  %s", method.upper(), path, safe)

        try:
            if method.upper() in ("GET", "DELETE"):
                resp = self._session.request(method, url, params=params, timeout=self.timeout)
            else:
                resp = self._session.request(method, url, data=params,   timeout=self.timeout)
        except requests.ConnectionError as exc:
            log.error("Network error: %s", exc)
            raise ConnectionError(f"Cannot reach {url}: {exc}") from exc
        except requests.Timeout as exc:
            log.error("Timeout after %ds", self.timeout)
            raise TimeoutError(f"Request to {url} timed out.") from exc

        log.debug("← HTTP %s  %s", resp.status_code, resp.text[:800])

        # Parse JSON (Binance always returns JSON)
        try:
            data = resp.json()
        except ValueError:
            data = {}

        # Binance error even on HTTP 200 → has negative 'code'
        if isinstance(data, dict) and data.get("code", 0) not in (0, 200):
            raise BinanceAPIError(
                code=data.get("code", -1),
                message=data.get("msg", "unknown"),
                http_status=resp.status_code,
            )

        if not resp.ok:
            raise BinanceAPIError(
                code=resp.status_code,
                message=str(data),
                http_status=resp.status_code,
            )

        return data

    # ── public API methods ─────────────────────────────────────────────────

    def get_server_time(self) -> dict:
        return self._request("GET", "/fapi/v1/time", signed=False)

    def get_account_info(self) -> dict:
        return self._request("GET", "/fapi/v2/account")

    def place_order(
        self,
        symbol:        str,
        side:          str,
        order_type:    str,
        quantity:      str,
        price:         Optional[str] = None,
        stop_price:    Optional[str] = None,
        time_in_force: Optional[str] = None,
        reduce_only:   bool          = False,
    ) -> dict:
        params: dict[str, Any] = {
            "symbol":       symbol,
            "side":         side,
            "type":         order_type,
            "quantity":     quantity,
            "positionSide": "BOTH",
        }
        if price:          params["price"]        = price
        if stop_price:     params["stopPrice"]    = stop_price
        if time_in_force:  params["timeInForce"]  = time_in_force
        if reduce_only:    params["reduceOnly"]   = "true"

        log.info(
            "Placing %s %s | symbol=%s qty=%s price=%s stop=%s tif=%s",
            side, order_type, symbol, quantity, price, stop_price, time_in_force,
        )
        result = self._request("POST", "/fapi/v1/order", params=params)
        log.info(
            "Order accepted | orderId=%s status=%s",
            result.get("orderId"), result.get("status"),
        )
        return result
