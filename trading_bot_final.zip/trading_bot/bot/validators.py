"""
Input validation for all order parameters.
Every function raises ValueError with a clear message on bad input.
"""
from __future__ import annotations
from decimal import Decimal, InvalidOperation
from typing import Optional

VALID_SIDES       = {"BUY", "SELL"}
VALID_ORDER_TYPES = {"MARKET", "LIMIT", "STOP_MARKET"}


def validate_symbol(symbol: str) -> str:
    if not symbol or not symbol.strip():
        raise ValueError("Symbol must not be empty.")
    clean = symbol.strip().upper()
    if not clean.isalnum():
        raise ValueError(f"Symbol '{clean}' must be alphanumeric only (e.g. BTCUSDT).")
    return clean


def validate_side(side: str) -> str:
    clean = side.strip().upper()
    if clean not in VALID_SIDES:
        raise ValueError(f"Side '{side}' is invalid — must be BUY or SELL.")
    return clean


def validate_order_type(order_type: str) -> str:
    clean = order_type.strip().upper()
    if clean not in VALID_ORDER_TYPES:
        raise ValueError(
            f"Order type '{order_type}' is invalid — must be "
            f"one of: {', '.join(sorted(VALID_ORDER_TYPES))}."
        )
    return clean


def validate_quantity(quantity) -> str:
    try:
        qty = Decimal(str(quantity))
    except InvalidOperation:
        raise ValueError(f"Quantity '{quantity}' is not a valid number.")
    if qty <= 0:
        raise ValueError(f"Quantity must be > 0, got {qty}.")
    return str(qty)


def validate_price(price: Optional[str], order_type: str) -> Optional[str]:
    if order_type == "MARKET":
        if price is not None and str(price).strip():
            raise ValueError("Do not supply --price for MARKET orders.")
        return None
    # LIMIT / STOP_MARKET need a price
    if not price or not str(price).strip():
        raise ValueError(f"--price is required for {order_type} orders.")
    try:
        p = Decimal(str(price))
    except InvalidOperation:
        raise ValueError(f"Price '{price}' is not a valid number.")
    if p <= 0:
        raise ValueError(f"Price must be > 0, got {p}.")
    return str(p)


def validate_stop_price(stop_price: Optional[str], order_type: str) -> Optional[str]:
    if order_type != "STOP_MARKET":
        return None
    if not stop_price or not str(stop_price).strip():
        raise ValueError("--stop-price is required for STOP_MARKET orders.")
    try:
        sp = Decimal(str(stop_price))
    except InvalidOperation:
        raise ValueError(f"Stop price '{stop_price}' is not a valid number.")
    if sp <= 0:
        raise ValueError(f"Stop price must be > 0, got {sp}.")
    return str(sp)


def validate_all(
    symbol: str,
    side: str,
    order_type: str,
    quantity,
    price=None,
    stop_price=None,
) -> dict:
    """Run all validations; return a dict of clean values."""
    clean_type = validate_order_type(order_type)
    return {
        "symbol":     validate_symbol(symbol),
        "side":       validate_side(side),
        "order_type": clean_type,
        "quantity":   validate_quantity(quantity),
        "price":      validate_price(price, clean_type),
        "stop_price": validate_stop_price(stop_price, clean_type),
    }
