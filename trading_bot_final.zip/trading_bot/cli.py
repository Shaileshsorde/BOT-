#!/usr/bin/env python3
"""
Binance Futures Testnet Trading Bot — CLI entry point.

Quick start
-----------
  pip install requests

  # Windows
  set BINANCE_API_KEY=<your_key>
  set BINANCE_API_SECRET=<your_secret>

  # macOS / Linux
  export BINANCE_API_KEY=<your_key>
  export BINANCE_API_SECRET=<your_secret>

Commands
--------
  python cli.py ping
  python cli.py account
  python cli.py order --symbol BTCUSDT --side BUY  --type MARKET     --quantity 0.001
  python cli.py order --symbol BTCUSDT --side SELL --type LIMIT      --quantity 0.001 --price 70000
  python cli.py order --symbol BTCUSDT --side BUY  --type STOP_MARKET --quantity 0.001 --stop-price 60000
"""

from __future__ import annotations

# ── make 'bot' importable no matter how/where this file is executed ────────────
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
# ──────────────────────────────────────────────────────────────────────────────

import argparse
import textwrap

from bot.client         import BinanceFuturesClient, BinanceAPIError
from bot.logging_config import setup_logging, get_logger
from bot.orders         import place_order

setup_logging()
log = get_logger("cli")


# ── terminal helpers ───────────────────────────────────────────────────────────

DIV   = "─" * 60
GREEN = "\033[92m"; RED  = "\033[91m"
CYAN  = "\033[96m"; BOLD = "\033[1m"; RESET = "\033[0m"

def _c(t, col):        return f"{col}{t}{RESET}" if sys.stdout.isatty() else t
def section(title):    print(f"\n{DIV}\n{_c('  ' + title, BOLD)}\n{DIV}")
def success(msg):      print(_c(f"\n  ✔  {msg}", GREEN))
def failure(msg):      print(_c(f"\n  ✘  {msg}", RED), file=sys.stderr)


# ── sub-command handlers ───────────────────────────────────────────────────────

def cmd_ping(client: BinanceFuturesClient, _args) -> int:
    section("Server Connectivity Check")
    try:
        data = client.get_server_time()
        print(f"  Server time (ms) : {data.get('serverTime')}")
        success("Connection to Binance Futures Testnet is healthy.")
        log.info("Ping OK — serverTime=%s", data.get("serverTime"))
        return 0
    except Exception as exc:
        failure(f"Ping failed: {exc}")
        log.error("Ping failed: %s", exc)
        return 1


def cmd_account(client: BinanceFuturesClient, _args) -> int:
    section("Account Information")
    try:
        d = client.get_account_info()
        print(f"  Total Wallet Balance   : {d.get('totalWalletBalance')} USDT")
        print(f"  Available Balance      : {d.get('availableBalance')} USDT")
        print(f"  Total Unrealised PnL   : {d.get('totalUnrealizedProfit')} USDT")
        print(f"  Can Trade              : {d.get('canTrade')}")
        log.info("Account fetched | balance=%s available=%s",
                 d.get("totalWalletBalance"), d.get("availableBalance"))
        return 0
    except BinanceAPIError as exc:
        failure(f"API error [{exc.code}]: {exc.message}")
        log.error("Account fetch failed: %s", exc)
        return 1
    except Exception as exc:
        failure(f"Unexpected error: {exc}")
        log.exception("Account fetch unexpected error")
        return 1


def cmd_order(client: BinanceFuturesClient, args) -> int:
    sym  = args.symbol.upper()
    side = args.side.upper()
    otyp = args.type.upper()

    # ── print request summary ──────────────────────────────────────────────
    section("Order Request Summary")
    print(f"  Symbol         : {_c(sym, CYAN)}")
    print(f"  Side           : {_c(side, GREEN if side == 'BUY' else RED)}")
    print(f"  Type           : {otyp}")
    print(f"  Quantity       : {args.quantity}")
    if args.price:      print(f"  Limit Price    : {args.price}")
    if args.stop_price: print(f"  Stop Price     : {args.stop_price}")
    if otyp == "LIMIT": print(f"  Time-In-Force  : {args.tif or 'GTC (default)'}")

    log.info("CLI order | symbol=%s side=%s type=%s qty=%s price=%s stop=%s",
             sym, side, otyp, args.quantity, args.price, args.stop_price)

    # ── place order ────────────────────────────────────────────────────────
    section("Placing Order …")
    try:
        result = place_order(
            client        = client,
            symbol        = sym,
            side          = side,
            order_type    = otyp,
            quantity      = args.quantity,
            price         = args.price,
            stop_price    = args.stop_price,
            time_in_force = args.tif,
            reduce_only   = args.reduce_only,
        )
    except ValueError as exc:
        failure(f"Validation error: {exc}")
        log.warning("Validation: %s", exc)
        return 2
    except BinanceAPIError as exc:
        failure(f"Binance API error [{exc.code}]: {exc.message}")
        log.error("API error: %s", exc)
        return 1
    except (ConnectionError, TimeoutError) as exc:
        failure(f"Network error: {exc}")
        log.error("Network: %s", exc)
        return 1
    except Exception as exc:
        failure(f"Unexpected error: {exc}")
        log.exception("Unexpected")
        return 1

    # ── print response ─────────────────────────────────────────────────────
    section("Order Response")
    for line in result.summary_lines():
        print(line)
    success(f"Order placed!  orderId={result.order_id}  status={result.status}")
    return 0


# ── argument parser ────────────────────────────────────────────────────────────

def _parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="cli",
        description=textwrap.dedent("""\
            Binance Futures Testnet Trading Bot
            ------------------------------------
            Supports MARKET, LIMIT, and STOP_MARKET orders on USDT-M Futures.
        """),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    p.add_argument("--api-key",    default=None, help="Binance API key   (default: BINANCE_API_KEY env var)")
    p.add_argument("--api-secret", default=None, help="Binance API secret (default: BINANCE_API_SECRET env var)")

    sub = p.add_subparsers(dest="command", metavar="COMMAND")
    sub.required = True

    sub.add_parser("ping",    help="Test connectivity to Binance Testnet.")
    sub.add_parser("account", help="Display account balance information.")

    o = sub.add_parser("order", help="Place a new futures order.")
    o.add_argument("--symbol",     "-s", required=True,                      help="Trading pair (e.g. BTCUSDT)")
    o.add_argument("--side",             required=True,                      help="BUY or SELL")
    o.add_argument("--type",       "-t", required=True, dest="type",         help="MARKET | LIMIT | STOP_MARKET")
    o.add_argument("--quantity",   "-q", required=True,                      help="Order quantity in base asset")
    o.add_argument("--price",      "-p", default=None,                       help="Limit price (required for LIMIT)")
    o.add_argument("--stop-price",       default=None, dest="stop_price",    help="Stop trigger price (required for STOP_MARKET)")
    o.add_argument("--tif",              default=None, choices=["GTC","IOC","FOK"], help="Time-in-force for LIMIT (default GTC)")
    o.add_argument("--reduce-only",      action="store_true", default=False, help="Reduce-only flag")
    return p


# ── entry point ────────────────────────────────────────────────────────────────

def main() -> None:
    args = _parser().parse_args()
    try:
        client = BinanceFuturesClient(api_key=args.api_key, api_secret=args.api_secret)
    except ValueError as exc:
        failure(str(exc))
        log.critical("Client init failed: %s", exc)
        sys.exit(1)

    sys.exit(
        {"ping": cmd_ping, "account": cmd_account, "order": cmd_order}[args.command](client, args)
    )


if __name__ == "__main__":
    main()
